
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Pamela Gonzalez
 */
public class Vendedor extends Persona{
    
     public Vendedor(String nombre, Date edad, String Apellido) {
        super(nombre, edad, Apellido);
        
        
    }
    
    
}

    
    